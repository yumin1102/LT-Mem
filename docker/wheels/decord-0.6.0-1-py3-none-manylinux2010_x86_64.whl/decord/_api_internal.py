"""Namespace for internal apis."""
